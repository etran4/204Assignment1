import java.util.ArrayList;
import java.util.regex.*;

/**
 *Utility class to check the password
 * @author Ethan Tran
 */

public class PasswordCheckerUtility 
{
    /**
     * Compare equality of two passwords
     * @param password - password string to be checked for
     * @param passwordConfirm - passwordConfirm string to be checked against password for
     * @throws UnmatchedException - thrown if not same (case sensitive)
     */
    static public void comparePasswords(String password, String passwordConfirm) throws UnmatchedException 
    {
        if (!password.equals(passwordConfirm)) 
        {
            throw new UnmatchedException("Passwords do not match");
        }
    }

    /**
     * Compare equality of two passwords
     * @param password - password string to be checked for
     * @param passwordConfirm - passwordConfirm string to be checked against password for
     * @return true if both same (case sensitive), false otherwise
     */
    static public boolean comparePasswordsWithReturn(String password, String passwordConfirm)  throws UnmatchedException
    {
        return password.equals(passwordConfirm);
    }

    /**
     * Checks the password length requirement - The password must be at least 6 characters long
     * @param password - password string to be checked for length
     * @return true if meets minimum length requirement
     * @throws LengthException - thrown if does not meet minimum length requirement
     */
    static public boolean isValidLength(String password) throws LengthException
    {
        if (password.length() < 6) 
        {
            throw new LengthException("The password must be at least 6 characters long");
        }
        return true;
    }

    /**
     * Checks the password alpha character requirement - Password must contain an uppercase alpha character
     * @param password - password string to be checked for alpha character requirement
     * @return true if meet alpha character requirement
     * @throws NoUpperAlphaException - thrown if does not meet alpha character requirement
     */
    static public boolean hasUpperAlpha(String password) throws NoUpperAlphaException
    {
        if (password.equals(password.toLowerCase()))
        {
            throw new NoUpperAlphaException("The password must contain at least one uppercase alphabetic character");
        }
        return true;
    }

    /**
     * Checks the password lowercase requirement - Password must contain at least one lowercase alpha character
     * @param password - password string to be checked for lowercase requirement
     * @return true if meets lowercase requirement
     * @throws NoLowerAlphaException - thrown if does not meet lowercase requirement
     */
    static public boolean hasLowerAlpha(String password) throws NoLowerAlphaException
    {
    	if (password.equals(password.toUpperCase())) 
        {
            throw new NoLowerAlphaException("The password must contain at least one lowercase alphabetic character");
        }
        return true;
    }

    /**
     * Checks the password Digit requirement - Password must contain a numeric character
     * @param password - password string to be checked for Digit requirement
     * @return true if meet Digit requirement
     * @throws NoDigitException - thrown if does not meet Digit requirement
     */
    static public boolean hasDigit(String password) throws NoDigitException
    {
    	char[] characters = password.toCharArray();
	    for(int i = 0; i < characters.length; i++) 
	    {
	        if(Character.isDigit(characters [i])) 
	        {
	        	return true;	        
        	}
	    }
	    throw new NoDigitException("The password must contain at least one digit");
    }

    /**
     * Checks the password SpecialCharacter requirement - Password must contain a Special Character
     * @param password - password string to be checked for SpecialCharacter requirement
     * @return true if meets SpecialCharacter requirement
     * @throws NoSpecialCharacterException - thrown if does not meet SpecialCharacter requirement
     */
    static public boolean hasSpecialChar(String password) throws NoSpecialCharacterException
    {
    	Pattern pattern = Pattern.compile("[a-zA-Z0-9]*");
		Matcher matcher = pattern.matcher(password);

    	if (matcher.matches()) 
        {
            throw new NoSpecialCharacterException("The password must contain at least one special character");
        }
        return true;
    }

    /**
     * Checks the password Sequence requirement - Password should not contain more than 2 of the same character in sequence
     * @param password - password string to be checked for Sequence requirement
     * @return false if does NOT meet Sequence requirement
     * @throws InvalidSequenceException - thrown if meets Sequence requirement
     */
    static public boolean NoSameCharInSequence(String password) throws InvalidSequenceException
    {
        if (Pattern.compile("([a-zA-Z0-9])\\1{2,}+").matcher(password).find()) 
        {
            throw new InvalidSequenceException("The password cannot contain more than two of the same character in sequence.");
        }
        return true;
    }

    /**
     * Return true if valid password (follows all the following rules), returns false if an invalid password
     * password - - string to be checked for validity
     * @returns true if valid password (follows all rules from above), false if an invalid passwo
     * @throws LengthException - thrown if length is less than 6 characters
     * @throws NoUpperAlphaException - thrown if no uppercase alphabetic
     * @throws NoLowerAlphaException - thrown if no lowercase alphabetic
     * @throws NoDigitException - thrown if no digit
     * @throws NoSpecialCharacterException - thrown if does not meet SpecialCharacter requirement
     * @throws InvalidSequenceException - thrown if more than 2 of same character.
     */
    static public boolean isValidPassword(String password) throws LengthException, NoUpperAlphaException, NoLowerAlphaException, NoDigitException, NoSpecialCharacterException, 
    InvalidSequenceException
    {
    	return isValidLength(password) && hasUpperAlpha(password) && hasLowerAlpha(password) && hasDigit(password) && hasSpecialChar(password) && NoSameCharInSequence(password);         
    }

    /**
     * Checks if the password contains 6 to 9 characters
     * @param password - password string to be checked for
     * @return true if password contains 6 to 9 characters, false otherwise
     */
    static public boolean hasBetweenSixAndNineChars(String password) 
    {
        return password.length() <= 9 && password.length() >= 6;
    }

    /**
     * Return true if valid password (follows all the following rules), returns false if an invalid password 1. At least 6 characters long - 2. At least 1 numeric character- 3. At least 1 uppercase alphabetic character - 4. At least 1 lowercase alphabetic character - 5. At least 1 special character - 6. No more than 2 of the same character in a sequence - Hello@123 � OK AAAbb@123 � not OK Aaabb@123 � OK
     * @param password - string to be checked if weak password
     * @return false if the password is valid and the length of password is NOT between 6 and 9 (inclusive)
     * @throws WeakPasswordException - if length of password is between 6 and 9 (inclusive), ALTHOUGH the password may be VALID.
     */
    static public boolean isWeakPassword (String password) throws WeakPasswordException 
    {
	try 
	{
		  isValidPassword(password);
		} catch(Exception exception) 
	{
		   throw new WeakPasswordException("The password is OK but weak - it contains fewer than 10 characters.");
		}
		if (hasBetweenSixAndNineChars(password)) 
		{
		throw new WeakPasswordException("The password is OK but weak - it contains fewer than 10 characters.");
		}
		return false;
    }

    /**
     * This method will accept an ArrayList of passwords as the parameter and return an ArrayList with the status of any invalid passwords (weak passwords are not considered invalid). The ArrayList of invalid passwords will be of the following format: password BLANK message of the exception thrown
     * @param passwords - list of passwords
     * @return ArrayList of invalid passwords in the correct format
     */
    static public ArrayList<String> getInvalidPasswords(ArrayList<String> passwords) 
    {
        ArrayList<String> invalid = new ArrayList<String>();

        for (int i = 0; i < passwords.size(); i++) 
        {
        	String password = passwords.get(i);
            try
            {
                isValidPassword(password);
            } 
            catch(RuntimeException exception) 
            {
                    invalid.add(password + " -> " + exception.getMessage());
            }
        }
        return invalid;
    }
}