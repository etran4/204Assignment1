/**
 *If password's length is less than 6 characters, an exception is thrown
 * @author Ethan Tran
 */
public class LengthException extends RuntimeException 
{
    public LengthException(String message)
{
        super(message);
    }
}