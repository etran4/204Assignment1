/**
 *If a password does not contain a special character, an exception is thrown
 * @author Ethan Tran
 */
public class NoSpecialCharacterException extends RuntimeException 
{    
    public NoSpecialCharacterException(String message) 
    {
        super(message);
    }
}
