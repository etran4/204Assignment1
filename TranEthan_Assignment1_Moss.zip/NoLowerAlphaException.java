/**
 *If a password does not contain a lowercase letter, an exception is thrown
 * @author Ethan Tran
 */
public class NoLowerAlphaException extends RuntimeException
{   
    public NoLowerAlphaException(String message)
    {
        super(message);
    }
}