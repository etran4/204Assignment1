/**
 *If a password is WEAK and if the length is between 6-9 characters, an exception is thrown
 * @author Ethan Tran
 */
public class WeakPasswordException extends RuntimeException 
{ 
    public WeakPasswordException(String message)
    {
        super(message);
    }
}