/**
 *If a password contains more than 2 adjacent characters in the same sequence, an exception is thrown
 * @author Ethan Tran
 */
public class InvalidSequenceException extends RuntimeException
{
    public InvalidSequenceException(String message) 
    {
        super(message);
    }
}