/**
 * If the password and the confirmation password do not match each other, an exception is thrown
 * @author Ethan Tran
 */
public class UnmatchedException extends RuntimeException 
{
    public UnmatchedException(String message) 
    {
        super(message);
    }
    public UnmatchedException() 
    {
    	super();
    }
}