/**
 *If a password does not contain a digit, an exception is thrown
 * @author Ethan Tran
 */
public class NoDigitException extends RuntimeException
{  
    public NoDigitException(String message) 
    {
        super(message);
    }
}