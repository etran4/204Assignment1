/**
 * If a password does not contain an uppercase character, an exception is thrown
 * @author Ethan Tran
 */
public class NoUpperAlphaException extends RuntimeException 
{
    public NoUpperAlphaException(String message) 
    {
        super(message);
    }
}